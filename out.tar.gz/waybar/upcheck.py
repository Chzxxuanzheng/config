import os
import subprocess
print('{"text":"测试"}')
'''
result = subprocess.run(['sudo', 'pacman', '-Sy'],stdout=subprocess.PIPE)
if result.returncode == 0:
    os.environ['text'] = "<span color=\'red\'>  </span>"
    print('"{"text": "<span color=\'red\'>  </span>","tooltip":"检查更新失败,请检查网络"}"')
    exit()

with os.popen('paru -Qu | wc -l') as c:
    result = c.read()

if result == 0:
    print('{"text": "<span color=\'green\'>  </span>","tooltip":"所有软件包均为最新版本"}')
else:
    print('{"text": "<span color=\'orange\'> '+result+' </span>","tooltip":"有'+ result +'个软件包需要更新"}')
'''
