from psutil import *
cpu = cpu_percent()
memory = virtual_memory()[2]
print(f' {cpu}%| {memory}%')
